<template>
  <div id="app">
    <h1>{{ msg }}</h1>
    <div class="app-header">
      <Header/>
    </div>
    <div class="app-content">
      <Content/>
    </div>
    <div class="app-footer">
      <Footer/>
    </div>
    <div class="home-one">
      <HomeWorkOne/>
    </div>
    <div class="home-two">
      <HomeWorkTwo/>
    </div>
    <div class="home-three">
      <HomeWorkThree/>
    </div>
    <div class="home-four">
      <HomeWorkFour/>
    </div>
    <div class="home-five">
      <HomeWorkFive/>
    </div>
    <div class="home-six">
      <HomeWorkSix/>
    </div>
    
    <HelloComponent/>
  </div>
</template>

<script>
import HelloComponent from './HelloComponent'
import Header from './components/Header'
import Content from './components/Content'
import Footer from './components/Footer'
import HomeWorkOne from './components/HomeWorkOne'
import HomeWorkTwo from './components/HomeWorkTwo'
import HomeWorkThree from './components/HomeWorkThree'
import HomeWorkFour from './components/HomeWorkFour'
import HomeWorkFive from './components/HomeWorkFive'
import HomeWorkSix from './components/HomeWorkSix'






export default {
  name: 'app',
  data () {
    return {
      msg: '基础模板'
    };
  },
  components:{
    HelloComponent,
    Header,
    Content,
    Footer,
    HomeWorkOne,
    HomeWorkTwo,
    HomeWorkThree,
    HomeWorkFour,
    HomeWorkFive,
    HomeWorkSix,
  }
}
</script>

<style scoped>
h1{
  color:red;
}
.home-one{
  background-color:red;
  width: 120px;
  height: 530px;
  margin-left:25%;
}
.home-one ul li{
  list-style: none;
}
.home-two{
  position: absolute;
  width: 600px;
  height: 200px;
  background-color: green;
  right: 275px;
  top:148px;
}
.home-three{
  position: absolute;
  width: 290px;
  height: 150px;
  background-color: gold;
  right: 585px;
  top:366px;
}
.home-four{
  position: absolute;
  width: 290px;
  height: 150px;
  background-color: gold;
  right: 275px;
  top:366px;
}
.home-five{
  position: absolute;
  width: 290px;
  height: 150px;
  background-color: gold;
  right: 585px;
  top:530px;
}
.home-six{
  position: absolute;
  width: 290px;
  height: 150px;
  background-color: gold;
  right: 275px;
  top:530px;
}
</style>
