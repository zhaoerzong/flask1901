<template>
    <h1>
        {{ msg }}
    </h1>
</template>

<script>
export default {
    data(){
        return{
            user:"热烈欢迎"
        }
    },
}
</script>

<style>
</style>