import Vue from 'vue'
import Base from './Base.vue'
// import HelloComponent from './HelloComponent.vue'
// import MyComponent from './MyComponent.vue'

new Vue({
  el: '#app',
  components:{
    Base,
    // HelloComponent,
    // MyComponent,
  },
  template:'<Base/>'
})
