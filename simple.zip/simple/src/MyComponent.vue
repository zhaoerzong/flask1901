<template>
    <h1>
        {{ user }}
    </h1>
</template>

<script>
export default {
    data(){
        return{
            user:"亲爱的聪"
        }
    },
}
</script>

<style>
</style>