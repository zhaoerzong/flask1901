<template>
    <div>
        <h5>像个大山</h5>
        <p>我的愿望世界和平</p>
        <a href="">立即购买</a>
    </div>
</template>