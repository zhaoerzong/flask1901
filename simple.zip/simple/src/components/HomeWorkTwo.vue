<template>
    <div>
        <span>
            不出意外的话这是一个轮播图
        </span>
    </div>
</template>