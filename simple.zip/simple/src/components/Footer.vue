<template>
    <div>
        我是Footer.vue单文件组件
    </div>
</template>