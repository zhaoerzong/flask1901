<template>
    <div>
        <h5>像个喇叭</h5>
        <p>比比谁的嗓门大</p>
        <a href="">立即购买</a>
    </div>
</template>