<template>
    <div>
        <h5>像个地球</h5>
        <p>保护环境人人有责</p>
        <a href="">立即购买</a>
    </div>
</template>