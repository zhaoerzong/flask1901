<template>
    <div>
        <h5>像个快递</h5>
        <p>顺丰快递单单必达</p>
        <a href="">立即购买</a>
    </div>
</template>